from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView, LogoutView
from django.db.models import Count
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, TemplateView, UpdateView
from .models import *
from .forms import *


class IncomingDocumentsView(TemplateView):
    template_name = 'main/incoming_doc.html'

    def get_queryset(self):
        return IncomingDocuments.objects.filter(pk=self.kwargs['pk'])

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        user = AdvUser.objects.get(username=self.request.user)
        if user.status == 'Делопроизводитель':
            context['docs'] = IncomingDocuments.objects.all()
        else:
            context['docs'] = IncomingDocuments.objects.filter(worker=self.request.user).filter(status='в работе')
        return context


class IncomingDocumentsUpdateView(UpdateView):
    model = IncomingDocuments
    fields = ['status']
    template_name_suffix = '_update_form'
    template_name = 'main/update_incoming_doc.html'
    success_url = reverse_lazy('incoming_doc')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class IncomingDocumentsCreateView(CreateView):
    model = IncomingDocuments
    template_name = 'main/create_incoming_doc.html'
    form_class = IncomingDocumentsCreateForm
    success_url = reverse_lazy('incoming_doc')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class SenderView(TemplateView):
    template_name = 'main/sender.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['senders'] = Sender.objects.all()
        return context


class SenderCreateView(CreateView):
    model = Sender
    template_name = 'main/create_sender.html'
    form_class = SenderCreateForm
    success_url = reverse_lazy('sender')  
    
    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class DocumentTypeView(TemplateView):
    template_name = 'main/doc_type.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['types'] = DocumentType.objects.all()
        return context


class DocumentTypeCreateView(CreateView):
    model = DocumentType
    template_name = 'main/create_doc_type.html'
    form_class = DocumentTypeCreateForm
    success_url = reverse_lazy('doc_type')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class OtchetView(TemplateView):
    template_name = 'main/otchet.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        user = AdvUser.objects.get(username=self.request.user)
        if user.status == 'Делопроизводитель':
            context['docs'] = Otchet.objects.all()
        else:
            context['docs'] = Otchet.objects.filter(user=self.request.user)
        return context


class OtchetCreateView(CreateView):
    template_name = 'main/create_otchet.html'
    model = Otchet
    form_class = OtchetCreateForm
    success_url = reverse_lazy('otchet')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class UndoneDocuments(TemplateView):
    template_name = 'main/undone_documents.html'
    
    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['docs'] = IncomingDocuments.objects.filter(status='в работе')
        return context


class DocumentByType(TemplateView):
    template_name = 'main/doc_by_type.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['result'] = IncomingDocuments.objects.values('document_type_id__name').annotate(total=Count('document_type'))
        return context


class DocumentByWorker(TemplateView):
    template_name = 'main/doc_by_worker.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['result'] = IncomingDocuments.objects.filter(status='в работе').values('worker__username').annotate(total=Count('worker'))
        return context


class MainPage(TemplateView):
    template_name = 'main/index.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class RegistrationFormView(CreateView):
    model = AdvUser
    form_class = AdvUserCreationForm
    template_name = 'main/registration.html'
    success_url = reverse_lazy('login')

    def post(self, request, *args, **kwargs):
        form = AdvUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            return redirect('login')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


class MainLoginView(LoginView):
    template_name = 'main/login.html'
    success_url = reverse_lazy('index')

    def get_success_url(self):
        return self.success_url


class MainLogoutView(LoginRequiredMixin, LogoutView):
    template_name = 'main/logout.html'
