from django.contrib import admin
from .models import *


@admin.register(Otchet)
class OtchetAdmin(admin.ModelAdmin):
    list_display = ['user', 'recipient', 'description', 'date', 'file',]


@admin.register(Sender)
class SenderAdmin(admin.ModelAdmin):
    list_display = ['name', 'address', 'phone']


@admin.register(DocumentType)
class DocumentTypeAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(IncomingDocuments)
class IncomingDocumentsAdmin(admin.ModelAdmin):
    list_display = ['document_type', 'sender', 'worker', 'status', 'term',
                    'description', 'date', 'file',]


admin.site.register(AdvUser)
