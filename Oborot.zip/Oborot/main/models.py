from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.dispatch import Signal

user_registrated = Signal()


class AdvUser(AbstractUser):
    CHOOSE = (
        ('Делопроизводитель', 'Делопроизводитель'),
        ('Специалист', 'Специалист'),
    )
    status = models.CharField('статус', max_length=512, choices=CHOOSE, default='Специалист')
    job_title = models.CharField('Должность', max_length=512)
    phone = models.CharField('Номер телефона', max_length=512)

    class Meta:
        verbose_name = 'Сотрудник'
        verbose_name_plural = 'Сотрудники'

    def __str__(self):
        return self.username

    def get_current_user(request):
        user = request.user
        return user

    def delete(self, *args, **kwargs):
        for bb in self.additionalimage_set.all():
            bb.delete()
        super().delete(*args, **kwargs)

    class Meta:
        pass


class Sender(models.Model):
    name = models.CharField('Отправитель', max_length=512)
    address = models.CharField('Адрес', max_length=512)
    phone = models.CharField('номер телефона', max_length=512)

    class Meta:
        verbose_name = 'Отправитель'
        verbose_name_plural = 'Отправители'

    def __str__(self):
        return self.name


class DocumentType(models.Model):
    name = models.CharField('Вид документа', max_length=512)

    class Meta:
        verbose_name = 'Вид документа'
        verbose_name_plural = 'Виды документов'

    def __str__(self):
        return self.name


class Otchet(models.Model):
    user = models.ForeignKey(AdvUser, on_delete=models.CASCADE, verbose_name='Сотрудник')
    recipient = models.ForeignKey(Sender, on_delete=models.CASCADE, verbose_name='Получатель')
    description = models.TextField('Описание')
    date = models.DateTimeField('Дата', default=timezone.now)
    file = models.FileField('Прикрепленный файл', upload_to='filesInput/output_files')


class IncomingDocuments(models.Model):
    STATUS_CHOICE = (
        ('в работе', 'в работе'),
        ('исполнен', 'исполнен'),
    )
    document_type = models.ForeignKey(DocumentType, on_delete=models.CASCADE, verbose_name='Вид документа')
    sender = models.ForeignKey(Sender, on_delete=models.CASCADE, verbose_name='Отправитель')
    worker = models.ForeignKey(AdvUser, on_delete=models.CASCADE, verbose_name='Сотрудник')
    status = models.CharField('Статус', max_length=512, choices=STATUS_CHOICE, default='в работе')
    term = models.PositiveIntegerField('Срок(в днях)')
    description = models.TextField('Описание')
    date = models.DateTimeField('Дата', default=timezone.now)
    file = models.FileField('Прикрепленный файл', upload_to='filesInput/input_files')

    class Meta:
        verbose_name = 'Входящий документ'
        verbose_name_plural = 'Входящие документы'
