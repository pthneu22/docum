from django.urls import path
from .views import *
urlpatterns = [
    path('', MainPage.as_view(), name='index'),
    path('incoming_doc/', IncomingDocumentsView.as_view(), name='incoming_doc'),
    path('create_incoming_doc/', IncomingDocumentsCreateView.as_view(), name='create_incoming_doc'),
    path('update_incoming_doc/<int:pk>', IncomingDocumentsUpdateView.as_view(), name='update_incoming_doc'),
    path('sender/', SenderView.as_view(), name='sender'),
    path('create_sender/', SenderCreateView.as_view(), name='create_sender'),
    path('doc_type/', DocumentTypeView.as_view(), name='doc_type'),
    path('create_doc_type/', DocumentTypeCreateView.as_view(), name='create_doc_type'),
    path('otchet/', OtchetView.as_view(), name='otchet'),
    path('create_otchet/', OtchetCreateView.as_view(), name='create_otchet'),
    path('undone_docs/', UndoneDocuments.as_view(), name='undone_docs'),
    path('doc_by_type/', DocumentByType.as_view(), name='doc_by_type'),
    path('doc_by_worker/', DocumentByWorker.as_view(), name='doc_by_worker'),
    path('register/', RegistrationFormView.as_view(), name='register'),
    path('login/', MainLoginView.as_view(), name='login'),
    path('logout/', MainLogoutView.as_view(), name='logout'),
]